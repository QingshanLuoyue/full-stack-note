# `react-interactions`

This package is experimental. It is intended for use with the experimental React
flags for internal testing.