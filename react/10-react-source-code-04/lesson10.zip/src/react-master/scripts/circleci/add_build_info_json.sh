#!/bin/bash

set -e

node ./scripts/release/ci-add-build-info-json.js
