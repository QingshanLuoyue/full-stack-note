#!/bin/bash		
		
set -e		
		
npm run bench