declare module 'merge-source-map' {
  export default function merge(oldMap: object, newMap: object): object
}
