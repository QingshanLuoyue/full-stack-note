describe('renderer: optimized mode', () => {
  test.todo('should work')
})
